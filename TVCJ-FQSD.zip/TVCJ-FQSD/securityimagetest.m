clc;
clear all;
%load position;
blocksize=4;
T=44;
save('T.mat');

h='Image/safari16.bmp';  %无攻击nc1，JPEG较差，其他良好

% w='200100732.jpg';
w='ldu.jpg';
% w='3073232.tif';
host=double(imread(h));
watermark=imread(w);
                                                %水印加密------------------------------------------
sk1=[0.56823603, 0.00427592, 0.71750067];
sk2=[0.12516930, 0.56120908, 0.87443383];


%     binaryWater(1,:)=encry2DLASM(watermark(:,:,1),sk1,sk2); 
%     binaryWater(2,:)=encry2DLASM(watermark(:,:,2),sk1,sk2); 
%     binaryWater(3,:)=encry2DLASM(watermark(:,:,3),sk1,sk2); 

binaryWater1=encry2DLASM(watermark(:,:,1),sk1,sk2); 
binaryWater2=encry2DLASM(watermark(:,:,2),sk1,sk2); 
binaryWater3=encry2DLASM(watermark(:,:,3),sk1,sk2); 

numDecimals = 1024
decWater1 = zeros(1, numDecimals);
decWater2 = zeros(1, numDecimals);
decWater3 = zeros(1, numDecimals);
for i = 1:numDecimals
    startIndex = (i - 1) * 8 + 1;
    endIndex = i * 8;
    decWater1(i) = bin2dec(binaryWater1(startIndex:endIndex));
    decWater2(i) = bin2dec(binaryWater2(startIndex:endIndex));
    decWater3(i) = bin2dec(binaryWater3(startIndex:endIndex));
end
colorImage = zeros(32, 32, 3);
colorImage(:,:,1) = reshape(decWater1, [32, 32]);
colorImage(:,:,2) = reshape(decWater2, [32, 32]);
colorImage(:,:,3) = reshape(decWater3, [32, 32]);

imshow(uint8(colorImage));
imwrite(uint8(colorImage),'AJiamiWatermark.bmp');
