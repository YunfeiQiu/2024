%testAttackCircle          
%�������� 

 clc;
clear all;
% T=44;
% load peppersUsablePos;
load binaryWater;
load('T.mat','T');
% load position;
rng(1);blocknum=512/4;waterlen=8192; 
position=randperm(blocknum^2,waterlen);
blocksize=4;
h='peppers.jpg';


% w='200100732.jpg';%
% w='3073232.tif';
w='ldu.jpg';
host=double(imread(h)); watermark=imread(w);  
watermarked=imread('watermarked.bmp'); 

%     [result]=jpegAttack(position,host,watermark,blocksize,watermarked,binaryWater,T);
%     [result]=jpeg2000Attack(position,host,watermark,blocksize,watermarked,binaryWater,T);
%     [result]=spNoiseAttack(position,host,watermark,blocksize,watermarked,binaryWater,T);
%     [result]=gaussianlowpassAttack(position,host,watermark,blocksize,watermarked,binaryWater,T);
%     [result]=croppingAttack(position,host,watermark,blocksize,watermarked,binaryWater,T);
%     [retult]=scalingAttacktest(position,host,watermark,blocksize,watermarked,binaryWater,T);
%     [result]=rotatingAttacktest(position,host,watermark,blocksize,watermarked,binaryWater,T);
%     [result]=translatingAttacktest(position,host,watermark,blocksize,watermarked,binaryWater,T);
    [result]=affiningAttacktest(position,host,watermark,blocksize,watermarked,binaryWater,T);
%     [result]=slantAttacktest(position,host,watermark,blocksize,watermarked,binaryWater,T);






