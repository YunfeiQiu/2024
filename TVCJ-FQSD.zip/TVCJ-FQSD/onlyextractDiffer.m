blocksize=4;
blocknum=512/blocksize;
rng(11); 
position=randperm(blocknum^2,waterlen);
waterlen=8192;
watermarked=double(imread('watermarked.bmp'));k=1;
for waterCount=48%1:waterlen
    %�ҵ���λ��
    pos=position(waterCount); 
    ii=floor((pos-1)/blocknum)+1;jj=mod(pos-1,blocknum)+1;
    for i=1:3
        block(:,:,i)=watermarked((ii-1)*blocksize+1:ii*blocksize,(jj-1)*blocksize+1:jj*blocksize,i);
    end 
    waterbit=extractWater(block,blocksize);
    bwatered(1,waterCount)=waterbit(1);bwatered(2,waterCount)=waterbit(2);bwatered(3,waterCount)=waterbit(3);
    
    for i=1:3
        if binaryWater(i,waterCount)~=bwatered(i,waterCount)
            differ1(k,1)=waterCount;differ1(k,2)=i;k=k+1;
            break;
        end
    end
end