%�������� ����   
function [result]=spNoiseAttack(position,host,watermark,blocksize,watermarked,x,T)
 
    waterlen=size(position,2);
    hostr=size(host,1);blocknum=floor(hostr/blocksize); ncmin=0;
%  for i=1:50
 
%     Q=[10];
%     for Qindex=1:length(Q) 
        na=imnoise(watermarked,'salt & pepper',0.002);
       
        attacked=double(na);

        for waterCount=1:waterlen
            %�ҵ���λ��
            pos=position(waterCount);
            ii=floor((pos-1)/blocknum)+1;jj=mod(pos-1,blocknum)+1;
            for i=1:3
                block(:,:,i)=attacked((ii-1)*blocksize+1:ii*blocksize,(jj-1)*blocksize+1:jj*blocksize,i);
            end

            waterbit=extractWater(block,blocksize,T);
            bwatered(1,waterCount)=waterbit(1);bwatered(2,waterCount)=waterbit(2);bwatered(3,waterCount)=waterbit(3);
        end
%         toc 
        psnrval=colorpsnr(uint8(attacked),uint8(host)); 

q=0;
            for level=1:3
                for i=1:8192
                    if bwatered(level,i)~=x(level,i)
                        q=q+1;
                    end
                end
            end
            ber=q/(8192*3);

        sk1=[0.56823603, 0.00427592, 0.71750067];
        sk2=[0.12516930, 0.56120908, 0.87443383];
        extractwatermark=decry2DLASM(bwatered,sk1,sk2);
        ncval=colornc(uint8(extractwatermark),uint8(watermark));
%         if ncval>ncmin
%             ncmin=ncval;
%             na=['./noiseExtractwater/peppers0.026-spNoise',num2str(ncval),'.bmp']; %'./extractwater/peppers37-JPEG0.999.bmp'
%             imwrite(uint8(extractwatermark),na);
%         end

%  end       

result=ncval;

    figure(3),imshow(uint8(extractwatermark)),title(ncval);
%     folder_name='attackfigure';
% file_name=sprintf('Salt&Peppers Noise(0.2%) NC=%s.jpg',num2str(ncval));
% file_path=fullfile(folder_name,file_name);
% imwrite(uint8(extractwatermark),'ldu Salt&Peppers Noise(0.2%).jpg');
    
    
    