%Cropping attack ����   ͼ��ֲ㹥��
function [result]=croppingAttack(position,host,watermark,blocksize,watermarked,x,T)
 

    waterlen=size(position,2);
    hostr=size(host,1);blocknum=floor(hostr/blocksize);

[rows, cols, channels] = size(watermarked);
ber_values = [];
p_values = [];
ncval_values = [];
% for p = 5:5:30
for p=5
    cut_size = sqrt(rows*rows * (p / 100));
    ca = watermarked;
    ca(1:cut_size, 1:cut_size, :) = 1; % ��ɫ����
    attacked=double(ca);
      for waterCount=1:waterlen
            %�ҵ���λ��
            pos=position(waterCount);
            ii=floor((pos-1)/blocknum)+1;jj=mod(pos-1,blocknum)+1;
            for i=1:3
                block(:,:,i)=attacked((ii-1)*blocksize+1:ii*blocksize,(jj-1)*blocksize+1:jj*blocksize,i);
            end
            waterbit=extractWater(block,blocksize,T);
            bwatered(1,waterCount)=waterbit(1);bwatered(2,waterCount)=waterbit(2);bwatered(3,waterCount)=waterbit(3);
        end
%         toc 
q=0;
            for level=1:3
                for i=1:8192
                    if bwatered(level,i)~=x(level,i)
                        q=q+1;
                    end
                end
            end
            ber=q/(8192*3);

        sk1=[0.56823603, 0.00427592, 0.71750067];
        sk2=[0.12516930, 0.56120908, 0.87443383];
        extractwatermark=decry2DLASM(bwatered,sk1,sk2);
        ncval=colornc(uint8(extractwatermark),uint8(watermark)); 
         
result=ncval;
 figure(1),subplot(121),imshow(ca),title('attacked hostimage');
  figure(1),subplot(122),imshow(uint8(extractwatermark)),title(['nc=',num2str(ncval)]);
% figure(p),imshow(uint8(extractwatermark)),title(['Cropping',num2str(p),'%','NC/BER=',num2str(ncval),'/',num2str(ber)]);
% folder_name='attackfigure';
% file_name=sprintf('Cropping(left30%) NC=%s.jpg',num2str(ncval));
% file_path=fullfile(folder_name,file_name);
% imwrite(uint8(extractwatermark),'peppCropping(left5%).jpg');
% ber_values = [ber_values, ber];
% ncval_values = [ncval_values, ncval];
%  p_values = [p_values, p];   
    
end

% data = [p_values; ber_values; ncval_values]';
% filename = 'cropresults.xlsx';
% 
% % д�����ݵ� Excel ������
% writematrix(data, filename, 'Sheet', 1, 'Range', 'A2');
% 
% % д���ͷ
% header = {'Cut Percentage', 'BER', 'NCVAL'};
% writecell(header, filename, 'Sheet', 1, 'Range', 'A1');
    