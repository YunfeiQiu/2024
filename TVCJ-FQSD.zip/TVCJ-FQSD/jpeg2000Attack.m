%JPEG2000 ����   ͼ��ֲ㹥��
function [result]=jpeg2000Attack(position,host,watermark,blocksize,watermarked,x,T)
%     load position;
    waterlen=size(position,2);
    hostr=size(host,1);blocknum=floor(hostr/blocksize); 
%     Q=[5,10];
    Q=[5];
%     watermarked=imread('watermarked.bmp');  
    for Qindex=1:length(Q)
%         tic
        for lev=1:3 
            imwrite(watermarked(:,:,lev),'temp.bmp','jp2','compressionratio',Q(Qindex));
            temp=imread('temp.bmp');   %temp.bmp Ϊѹ�����ͼƬ
            attacked(:,:,lev)=double(temp);
        end  
        for waterCount=1:waterlen
            %�ҵ���λ��
            pos=position(waterCount); 
            ii=floor((pos-1)/blocknum)+1;jj=mod(pos-1,blocknum)+1;
            for i=1:3
                block(:,:,i)=attacked((ii-1)*blocksize+1:ii*blocksize,(jj-1)*blocksize+1:jj*blocksize,i);
            end

            waterbit=extractWater(block,blocksize,T);
            bwatered(1,waterCount)=waterbit(1);bwatered(2,waterCount)=waterbit(2);bwatered(3,waterCount)=waterbit(3);
 
        end
q=0;
            for level=1:3
                for i=1:8192
                    if bwatered(level,i)~=x(level,i)
                        q=q+1;
                    end
                end
            end
            ber=q/(8192*3);


%         toc   
        sk1=[0.56823603, 0.00427592, 0.71750067];
        sk2=[0.12516930, 0.56120908, 0.87443383];
        extractwatermark=decry2DLASM(bwatered,sk1,sk2);
        ncval=colornc(uint8(extractwatermark),uint8(watermark));
%         psnrval=colorpsnr(uint8(attacked),uint8(host));
        
        
%         result(Qindex,1)=Q(Qindex); 
%         result(Qindex,2)=ncval;
result=ncval;

%         figure(1),imshow(uint8(extractwatermark)),title(ncval);
figure(2),imshow(uint8(extractwatermark)),title(['JPEG2000',num2str(Q),':1  NC/BER=',num2str(ncval),num2str(ber)]);
% folder_name='attackfigure';
% saveas(gcf,fullfile(folder_name,'JPEG2000.png'));
% folder_name='attackfigure';
% file_name=sprintf('JPEG2000(5:1) NC=%s.jpg',num2str(ncval));
% file_path=fullfile(folder_name,file_name);
% imwrite(extractwatermark,file_path);
% imwrite(uint8(extractwatermark),'jpeg2000.jpg');
    end 
    
    
    
    
    