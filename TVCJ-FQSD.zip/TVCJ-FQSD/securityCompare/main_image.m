 clc;
clear all;
w='ldu.jpg'; %200100732 ldu
watermark=imread(w);

%ˮӡ����-----2D-LASM-------------------------------------
sk1=[0.56823603, 0.00427592, 0.71750067];
sk2=[0.12516930, 0.56120908, 0.87443383];
for level=1:3
    binaryWater(:,:,level)=encry2DLASM_dec(watermark(:,:,level),sk1,sk2);  %�ֲ����Ҳ���ÿ������ֵת��Ϊ8λ����������
end
figure(1);
subplot(131),imshow(uint8(binaryWater));
imwrite(uint8(binaryWater),'LASMldu.bmp');

%--------------------------------------------------

%ˮӡ����-----Arnold-------------------------------------
for level=1:3
    binaryWater2(:,:,level)=Arnoldmodify(watermark(:,:,level),14,0);       %�ֲ����� 
end
subplot(132),imshow(uint8(binaryWater2));
imwrite(uint8(binaryWater2),'Arnoldldu.bmp');
%--------------------------------------------------

%ˮӡ����-----Affine-------------------------------------
a=1; b=-1; c=-1; d=0; key=6;
for level=1:3
    binaryWater3(:,:,level)=Affine(watermark(:,:,level),a,b,c,d,key,0);  
end
subplot(133),imshow(uint8(binaryWater3));
imwrite(uint8(binaryWater3),'Affineldu.bmp');
%--------------------------------------------------


