 clc;
clear all;
w='ldu.jpg'; %200100732
watermark=imread(w);
%����ǰ-------------------------------------
for level=1:3
    levelwatermark(level,:)=gainlevelwatermark(watermark(:,:,level));%���Һ��ÿ������ֵת��Ϊ8λ����������
end
count0=[0,0,0,0]; count1=[0,0,0,0];
for level=1:3
    for i=1:8192
        if levelwatermark(level,i)=='0'
            count0(level)=count0(level)+1;
        elseif levelwatermark(level,i)=='1'
            count1(level)=count1(level)+1;
        end
    end
    count0(4)=count0(4)+count0(level);
    count1(4)=count1(4)+count1(level);
end
%--------------------------------------------------

%ˮӡ����-----2D-LASM-------------------------------------
sk1=[0.56823603, 0.00427592, 0.71750067];
sk2=[0.12516930, 0.56120908, 0.87443383];
for level=1:3
    binaryWater(level,:)=encry2DLASM(watermark(:,:,level),sk1,sk2);  %�ֲ����Ҳ���ÿ������ֵת��Ϊ8λ����������
end

LASMcount0=[0,0,0,0]; LASMcount1=[0,0,0,0];
for level=1:3
    for i=1:8192
        if binaryWater(level,i)=='0'
            LASMcount0(level)=LASMcount0(level)+1;
        elseif binaryWater(level,i)=='1'
            LASMcount1(level)=LASMcount1(level)+1;
        end
    end
    LASMcount0(4)=LASMcount0(4)+LASMcount0(level);
    LASMcount1(4)=LASMcount1(4)+LASMcount1(level);
end
%--------------------------------------------------

%ˮӡ����-----Arnold-------------------------------------
for level=1:3
    M=Arnoldmodify(watermark(:,:,level),14,0);       %�ֲ����� 
    levelwatermark(level,:)=gainlevelwatermark(M);%���Һ��ÿ������ֵת��Ϊ8λ����������
end
Arnoldcount0=[0,0,0,0]; Arnoldcount1=[0,0,0,0];
for level=1:3
    for i=1:8192
        if levelwatermark(level,i)=='0'
            Arnoldcount0(level)=Arnoldcount0(level)+1;
        elseif levelwatermark(level,i)=='1'
            Arnoldcount1(level)=Arnoldcount1(level)+1;
        end
    end
    Arnoldcount0(4)=Arnoldcount0(4)+Arnoldcount0(level);
    Arnoldcount1(4)=Arnoldcount1(4)+Arnoldcount1(level);
end
%--------------------------------------------------

%ˮӡ����-----Affine-------------------------------------
a=1; b=-1; c=-1; d=0; key=6;
for level=1:3
    afterAffine=Affine(watermark(:,:,level),a,b,c,d,key,0); 
    levelwatermark2(level,:)=gainlevelwatermark(afterAffine);
end
Affinecount0=[0,0,0,0]; Affinecount1=[0,0,0,0];
for level=1:3
    for i=1:8192
        if levelwatermark2(level,i)=='0'
            Affinecount0(level)=Affinecount0(level)+1;
        elseif levelwatermark2(level,i)=='1'
            Affinecount1(level)=Affinecount1(level)+1;
        end
    end
    Affinecount0(4)=Affinecount0(4)+Affinecount0(level);
    Affinecount1(4)=Affinecount1(4)+Affinecount1(level);
end
%--------------------------------------------------


