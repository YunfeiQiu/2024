clc;
clear all;
%load position;
blocksize=4;
T=44;
save('T.mat');

h='Image1/safari16.bmp';  %无攻击nc1，JPEG较差，其他良好

w='200100732.jpg';
% w='ldu.jpg';
% w='3073232.tif';
host=double(imread(h));
watermark=imread(w);
image = uint8(watermark);

% 初始化3×8192的char矩阵
binary_matrix = char(zeros(3, 8192));

% 遍历图像的每个通道
for channel = 1:3
    % 初始化当前通道的二进制字符串
    binary_string = '';
    
    for row = 1:32
        for col = 1:32
            % 获取像素值
            pixel_value = image(row, col, channel);
            
            % 将像素值转换为8位二进制字符串
            binary_value = dec2bin(pixel_value, 8);
            
            % 连接二进制字符串
            binary_string = [binary_string binary_value];
        end
    end
    
    % 将二进制字符串存储到矩阵的相应位置
    binary_matrix(channel, :) = binary_string;
end
for channel = 1:3
    % 初始化当前通道的二进制字符串
    binary_string = '';
    
    for row = 1:32
        for col = 1:32
            % 获取像素值
            pixel_value = image(row, col, channel);
            
            % 将像素值转换为8位二进制字符串
            binary_value = dec2bin(pixel_value, 8);
            
            % 连接二进制字符串
            binary_string = [binary_string binary_value];
        end
    end
    
    % 将二进制字符串存储到矩阵的相应位置
    binary_matrix(channel, :) = binary_string;
end

% 初始化计数变量
num_zeros = zeros(3, 1);
num_ones = zeros(3, 1);

% 计算每层的0和1的个数
for channel = 1:3
    num_zeros(channel) = sum(binary_matrix(channel, :) == '0');
    num_ones(channel) = sum(binary_matrix(channel, :) == '1');
end

% 显示结果
for channel = 1:3
    fprintf('Channel %d - Number of 0s: %d, Number of 1s: %d\n', channel, num_zeros(channel), num_ones(channel));
end
 