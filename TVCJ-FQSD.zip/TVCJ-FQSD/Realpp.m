function AR=Realpp(A1,A2,A3,A4)
AR=[A1, -A2, -A3, -A4;
    A2,  A1, -A4,  A3;
    A3,  A4,  A1, -A2;
    A4, -A3,  A2,  A1];