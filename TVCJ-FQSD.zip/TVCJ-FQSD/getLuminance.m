function lumi=getLuminance(mat)
lumi=zeros(size(mat,1),size(mat,2));
for i=1:size(mat,1)
    for j=1:size(mat,2)
        lumi(i,j)=0.299*mat(i,j,1)+0.114*mat(i,j,2)+0.587*mat(i,j,3);
    end
end