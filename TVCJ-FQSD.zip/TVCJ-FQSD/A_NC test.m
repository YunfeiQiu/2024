%testAttackCircle          
%�������� 

 clc;
clear all;
% T=44;
% load peppersUsablePos;
load binaryWater;
% load position;
rng(1);blocknum=512/4;waterlen=8192; 
position=randperm(blocknum^2,waterlen);
blocksize=4;
load('T.mat','T');
h='peppers.jpg';


w='200100732.jpg';%200100732
% w='ldu.jpg';
host=double(imread(h)); watermark=imread(w);  
watermarked=imread('watermarked.bmp'); 

    result1=jpegAttack(position,host,watermark,blocksize,watermarked,binaryWater);
    result2=jpeg2000Attack(position,host,watermark,blocksize,watermarked);
   result3=spNoiseAttack(position,host,watermark,blocksize,watermarked);
   result4=gaussianlowpassAttack(position,host,watermark,blocksize,watermarked);

    
% results=[T,result1,result2,result3,result4,result5,result6,result7,result8];
filename = 'AttackResults.xlsx';
existing_data=readmatrix(filename,'Sheet','Results');
new_data = [T, result1, result2, result3, result4];
all_data = [existing_data; new_data];
writematrix(all_data, filename, 'Sheet', 'Results');

