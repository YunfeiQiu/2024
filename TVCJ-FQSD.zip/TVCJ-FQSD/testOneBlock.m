%testOneBlock
load position;
lambda=44;blocksize=4;h='peppers.jpg';blocknum=512/blocksize;qblock=zerosq(blocksize,blocksize);
host=double(imread(h));
w='200100732.jpg';watermark=imread(w); 

for level=1:3
    am=arnoldModify(watermark(:,:,level),14,0);       %�ֲ�����
    waterArnold(:,:,level)=am;
    binaryWater(level,:)=waterToBinary(am);%���Һ��ÿ������ֵת��Ϊ8λ����������
end
    %Ƕ��
    poslev=2;poscount=274;
    pos=position(poslev,poscount);
    ii=floor((pos-1)/blocknum)+1;jj=mod(pos-1,blocknum)+1;
    for i=1:3
        block(:,:,i)=host((ii-1)*blocksize+1:ii*blocksize,(jj-1)*blocksize+1:jj*blocksize,i);
    end
    %ȫ0�ж�
    for i=1%1:3
        if block(1,1,i)==0
            block(1,1,i)=1;
        end
    end
    %ÿ�������������Ԫ����ʾ
    for i=1:blocksize
        for j=1:blocksize
            qblock(i,j)=quaternion(block(i,j,1),block(i,j,2),block(i,j,3));
        end
    end
    %һ����ֻ��Ƕ��1bitˮӡ
    waterbit=binaryWater(poslev,poscount);
    [qblocknew]=embedWaterTest(qblock,lambda,waterbit);
  
    %Ƕ��ˮӡ�Ŀ����ԭ��
    for i=1:blocksize
        for j=1:blocksize
            blocknew(i,j,1)=getx(qblocknew(i,j));
            blocknew(i,j,2)=gety(qblocknew(i,j));
            blocknew(i,j,3)=getz(qblocknew(i,j));
        end
    end 
    
    %��ȡ
    block=uint8(blocknew);
    for i=1:blocksize
        for j=1:blocksize
            qblock(i,j)=quaternion(block(i,j,1),block(i,j,2),block(i,j,3));
        end
    end
    waterbit=extractWater(qblock,lambda);
    