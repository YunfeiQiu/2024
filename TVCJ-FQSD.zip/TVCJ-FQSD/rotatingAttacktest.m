%rotate ����   ͼ��ֲ㹥��
function [result]=rotatingAttacktest(position,host,watermark,blocksize,watermarked,x,T)
 
    waterlen=size(position,2);
    hostr=size(host,1);blocknum=floor(hostr/blocksize); 
    attacked=double(RotatingAttack(watermarked,5)); 
% attackimg=imrotate(watermarked,15) ;
% [cornerpoint,attacktype]=LocatingVertices4(attackimg);
% if attacktype %ƽ��
%     watermarked=CorrectingTranslate2(attackimg,cornerpoint);
% else %�������
%     src1=[cornerpoint(:,:,1);cornerpoint(:,:,2);cornerpoint(:,:,3);cornerpoint(:,:,4)];
%     pt_M=512; 
%     tar1=[1,1;pt_M,1;pt_M,pt_M;1,pt_M];
%     TForm1 = fitgeotrans(src1,tar1,'Projective'); %Projective
%     attackimg_pt = imwarp(attackimg, TForm1);
%     watermarked=RemovingBlackEdges4(attackimg_pt,512,512); % ȥ�ڱ�
% %     attacked=antialiasingProcess(double(watermarked)); %����ݣ���������
% attacked=sawtoothProcess(double(watermarked));
% end
        for waterCount=1:waterlen
            %�ҵ���λ��
            pos=position(waterCount); 
            ii=floor((pos-1)/blocknum)+1;jj=mod(pos-1,blocknum)+1;
            for i=1:3
                block(:,:,i)=attacked((ii-1)*blocksize+1:ii*blocksize,(jj-1)*blocksize+1:jj*blocksize,i);
            end
            waterbit=extractWater(block,blocksize,T);
            bwatered(1,waterCount)=waterbit(1);bwatered(2,waterCount)=waterbit(2);bwatered(3,waterCount)=waterbit(3);
 
        end
% %         toc   
        sk1=[0.56823603, 0.00427592, 0.71750067];
        sk2=[0.12516930, 0.56120908, 0.87443383];
        extractwatermark=decry2DLASM(bwatered,sk1,sk2);
        ncval=colornc(uint8(extractwatermark),uint8(watermark));
%         psnrval=colorpsnr(uint8(attacked),uint8(host));
       result=ncval;
        q=0;
            for level=1:3
                for i=1:8192
                    if bwatered(level,i)~=x(level,i)
                        q=q+1;
                    end
                end
            end
            ber=q/(8192*3);
   
%        figure(1),subplot(121),imshow(uint8(attacked));
       figure(7), imshow(uint8(extractwatermark)),title(['rotating NC/BER=',num2str(ncval),'/',num2str(ber)]);
% folder_name='attackfigure';
% file_name=sprintf('Rotating115�� NC=%s.jpg',num2str(ncval));
% file_path=fullfile(folder_name,file_name);
% imwrite(uint8(extractwatermark),file_path);
    end 
    
    
    
    
    