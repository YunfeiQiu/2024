function img=AffineAttack(watermarkedimg,b,c)

    % %------------仿射变换 -------%%
    in_points = [1 b 0;c 1 0;0 0 1];%仿射变换
    %[0.9, 0.2, 0; 0.1, 1.2, 0; 0, 0, 1] 
    %     tform = maketform('affine', in_points); %创建结构体
    %     img = imtransform(watermarkedimg,tform);%执行仿射变换
    tform2=affine2d(in_points);
    img = imwarp(watermarkedimg,tform2);%执行仿射变换
    figure(2), imshow(uint8(img)),title('仿射变换'); %显示变换结果
    %    

end



