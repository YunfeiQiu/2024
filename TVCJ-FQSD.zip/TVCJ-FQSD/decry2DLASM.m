function extractwatermark=decry2DLASM(bwatered,sk1,sk2) 

    p=32;%size(watermark,1);
    q=32;%size(watermark,2); %watermark is p��q
    pai=3.14159265;
    x1(1)=sk1(1);y1(1)=sk1(2);u1=sk1(3);
    x2(1)=sk2(1);y2(1)=sk2(2);u2=sk2(3);
    for i=1:p*q
       x1(i+1)=sin(pai*u1*(y1(i)+3)*x1(i)*(1-x1(i))); 
       y1(i+1)=sin(pai*u1*(x1(i+1)+3)*y1(i)*(1-y1(i)));

       x2(i+1)=sin(pai*u2*(y2(i)+3)*x2(i)*(1-x2(i))); 
       y2(i+1)=sin(pai*u2*(x2(i+1)+3)*y2(i)*(1-y2(i)));
    end
    s1=y1(2:length(y1));
    s2=y2(2:length(y1));

    [~,L]=sort(s1); 
    [~,L2]=sort(s2); 
    L2=mod(L2,255);

    for lev=1:3
        for i=1:size(bwatered,2)/8
            decwatered(1,i)=bin2dec(bwatered(lev,(i-1)*8+1:i*8));
        end
        watershuffle=(bitxor(uint8(decwatered),uint8(L2)));
        for i=1:p*q
            waterseq(L(i))=watershuffle(i);
        end
        watermark(:,:,lev)=reshape(waterseq,p,q); 
    end
    extractwatermark=watermark;
%     figure(1),subplot(121),imshow(uint8(watermark)),title('watermark');

