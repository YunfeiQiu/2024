%平移
function [result]=translatingAttacktest(position,host,watermark,blocksize,watermarked,x,T)
 
    waterlen=size(position,2);
    hostr=size(host,1);blocknum=floor(hostr/blocksize); 


    attacked=double(TranslatingAttack(watermarked,35,-25)); 

   %%%%%%%%%%%%%矫正
[cornerpoint,attacktype]=LocatingVertices4(attacked);
if attacktype %平移
    attacked=CorrectingTranslate2(attacked,cornerpoint);
else %其他情况
    src1=[cornerpoint(:,:,1);cornerpoint(:,:,2);cornerpoint(:,:,3);cornerpoint(:,:,4)];
    pt_M=512; 
    tar1=[1,1;pt_M,1;pt_M,pt_M;1,pt_M];
    TForm1 = fitgeotrans(src1,tar1,'Projective'); %Projective
    attackimg_pt = imwarp(attacked, TForm1);

    watermarked=RemovingBlackEdges4(attackimg_pt,512,512); 
    watermarked=antialiasingProcess(double(watermarked)); 

end

        for waterCount=1:waterlen
            pos=position(waterCount); 
            ii=floor((pos-1)/blocknum)+1;jj=mod(pos-1,blocknum)+1;
            for i=1:3
                block(:,:,i)=attacked((ii-1)*blocksize+1:ii*blocksize,(jj-1)*blocksize+1:jj*blocksize,i);
            end
            waterbit=extractWater(block,blocksize,T);
            bwatered(1,waterCount)=waterbit(1);bwatered(2,waterCount)=waterbit(2);bwatered(3,waterCount)=waterbit(3);
 
        end
%         toc   
        sk1=[0.56823603, 0.00427592, 0.71750067];
        sk2=[0.12516930, 0.56120908, 0.87443383];
        extractwatermark=decry2DLASM(bwatered,sk1,sk2);
        ncval=colornc(uint8(extractwatermark),uint8(watermark));
%         psnrval=colorpsnr(uint8(attacked),uint8(host));
       result=ncval;
        q=0;
            for level=1:3
                for i=1:8192
                    if bwatered(level,i)~=x(level,i)
                        q=q+1;
                    end
                end
            end
            ber=q/(8192*3);
   
%        figure(1),subplot(121),imshow(uint8(attacked));
       figure(8), imshow(uint8(extractwatermark)),title(ncval);
%         result(Qindex,1)=Q(Qindex); 
%         result(Qindex,2)=ncval;
% folder_name='attackfigure';
% file_name=sprintf('TranslateAttack() NC=%s.jpg',num2str(ncval));
% % file_name=sprintf('TranslateAttack(-35,0) NC=%s.jpg',num2str(ncval));
% file_path=fullfile(folder_name,file_name);
% imwrite(uint8(extractwatermark),file_path);
    end 
    
    
    
    
    