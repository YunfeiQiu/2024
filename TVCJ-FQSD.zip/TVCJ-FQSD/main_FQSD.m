clc;
clear all;
%load position;
blocksize=4;
T=44;
save('T.mat');
h='Image1/peppers.jpg';
% 
% w='200100732.jpg';
w='ldu.jpg';
% w='3073232.tif';
host=double(imread(h));
watermark=imread(w);
                                                %水印加密------------------------------------------
sk1=[0.56823603, 0.00427592, 0.71750067];
sk2=[0.12516930, 0.56120908, 0.87443383];
 for level=1:3
    binaryWater(level,:)=encry2DLASM(watermark(:,:,level),sk1,sk2); 
 end
save("binaryWater.mat");

% num_zeros = zeros(3, 1);
% num_ones = zeros(3, 1);
% for i = 1:3
%     num_zeros(i) = sum(binaryWater(i, :) == '0');
%     num_ones(i) = sum(binaryWater(i, :) == '1');
% end
% for i = 1:3
%     fprintf('Layer %d - Number of 0s: %d\n', i, num_zeros(i));
%     fprintf('Layer %d - Number of 1s: %d\n', i, num_ones(i));
% end
%--------------------------------------------------

%随机产生嵌入位置
hostr=size(host,1);
waterlen=size(binaryWater,2);%32*32*8=8192
blocknum=floor(hostr/blocksize);%512/4=128

rng(11); 
%  position=randperm(blocknum^2,waterlen); 
load position;
watermarked=host;
%-----
%水印的嵌入
tic 
for waterCount=1:waterlen
    if waterCount>8192
     break;
    end
    %找到块位置
    pos=position(waterCount); 
    ii=floor((pos-1)/blocknum)+1;jj=mod(pos-1,blocknum)+1;
    for i=1:3
        block(:,:,i)=host((ii-1)*blocksize+1:ii*blocksize,(jj-1)*blocksize+1:jj*blocksize,i);
    end   
     

    for i=1:3
         oo=rand(4,4)-0.5;
         block(:,:,i)=block(:,:,i)+oo;
    end 
    for k=1:3
        for i=1:blocksize
            for j=1:blocksize
                if sign(block(i,j,k)) == -1  
                    block(i,j,k)=-block(i,j,k);
                end
            end
        end
    end 
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 
    waterbit(1)=binaryWater(1,waterCount);waterbit(2)=binaryWater(2,waterCount);waterbit(3)=binaryWater(3,waterCount);

blocknew=embedWater(block,T,waterbit,blocksize);

     watermarked((ii-1)*blocksize+1:ii*blocksize,(jj-1)*blocksize+1:jj*blocksize,1)=blocknew(1+blocksize:2*blocksize,1:blocksize);
     watermarked((ii-1)*blocksize+1:ii*blocksize,(jj-1)*blocksize+1:jj*blocksize,2)=blocknew(1+2*blocksize:3*blocksize,1:blocksize);
     watermarked((ii-1)*blocksize+1:ii*blocksize,(jj-1)*blocksize+1:jj*blocksize,3)=blocknew(1+3*blocksize:4*blocksize,1:blocksize);

end

time1=toc;
disp(['嵌入代码运行时间：', num2str(time1), ' 秒']);
psnr=colorpsnr(uint8(host),uint8(watermarked));%colorpsnr和colornc都没有imread
ssim=colorssim(watermarked,host);
imwrite(uint8(watermarked),'watermarked.bmp');
figure(3),subplot(131),imshow(uint8(host)),title('Original image');
subplot(132),imshow('watermarked.bmp'),title([' PSNR=',num2str(psnr),' ssim=',num2str(ssim)]);
% --------------------------------------------------

%水印提取------------------------------------------
tic
watermarked=double(imread('watermarked.bmp'));k=1;


for waterCount=1:waterlen
    %找到块位置
    pos=position(waterCount); 
    ii=floor((pos-1)/blocknum)+1;jj=mod(pos-1,blocknum)+1;
    for i=1:3
        block(:,:,i)=watermarked((ii-1)*blocksize+1:ii*blocksize,(jj-1)*blocksize+1:jj*blocksize,i);
    end 
    
waterbit=extractWater(block,blocksize,T);
bwatered(1,waterCount)=waterbit(1);bwatered(2,waterCount)=waterbit(2);bwatered(3,waterCount)=waterbit(3);
    

end
extractwatermark=decry2DLASM(bwatered,sk1,sk2);
time2=toc;
disp(['提取代码运行时间：', num2str(time2), ' 秒']);
imwrite(uint8(extractwatermark),'extractwatermark.bmp'); 
ncval=colornc(uint8(extractwatermark),uint8(watermark));
subplot(133),imshow('extractwatermark.bmp'),title(['nc=',num2str(ncval)]);


