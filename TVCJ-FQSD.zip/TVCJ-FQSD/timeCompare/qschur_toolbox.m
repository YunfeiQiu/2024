 clc;
clear all;
%load position;
blocksize=4;
% T=0.026;
T=44;
save('T.mat');
h='peppers.jpg';
w='200100732.jpg'; %200100732
host=double(imread(h));
watermark=imread(w);
%ˮӡ����------------------------------------------
tic
sk1=[0.56823603, 0.00427592, 0.71750067];
sk2=[0.12516930, 0.56120908, 0.87443383];
for level=1:3
    binaryWater(level,:)=encry2DLASM(watermark(:,:,level),sk1,sk2);  %�ֲ����Ҳ���ÿ������ֵת��Ϊ8λ����������
end
encryptime=toc;
% count0=[0,0,0];count1=[0,0,0];
% for level=1:3
%     for i=1:8192
%         if binaryWater(level,i)=='0'
%             count0(level)=count0(level)+1;
%         elseif binaryWater(level,i)=='1'
%             count1(level)=count1(level)+1;
%         end
%     end
% end
%--------------------------------------------------

%�������Ƕ��λ��
tic
hostr=size(host,1);
waterlen=size(binaryWater,2);%32*32*8=8192
blocknum=floor(hostr/blocksize);%512/4=128

rng(1); 
position=randperm(blocknum^2,waterlen); 
randpermtime=toc;
%-----

%ˮӡ��Ƕ��
tic
watermarked=host;
qblock=zerosq(blocksize,blocksize);
for waterCount=1:waterlen
    %�ҵ���λ��
    pos=position(waterCount); 
    ii=floor((pos-1)/blocknum)+1;jj=mod(pos-1,blocknum)+1;
    for i=1:3
        block(:,:,i)=host((ii-1)*blocksize+1:ii*blocksize,(jj-1)*blocksize+1:jj*blocksize,i);
    end   
    %���Ӷ�������
%     for i=1:3
%          oo=rand(4,4)-0.5;
%          block(:,:,i)=block(:,:,i)+oo;
%     end 
    for k=1:3
        for i=1:blocksize
            for j=1:blocksize
                if sign(block(i,j,k)) == -1  
                    block(i,j,k)=-block(i,j,k);
                end
            end
        end
    end 
    %---
    %---ÿ�������������Ԫ����ʾ
        for i=1:blocksize
            for j=1:blocksize
                qblock(i,j)=quaternion(block(i,j,1),block(i,j,2),block(i,j,3));
            end
        end
    %-------
    waterbit(1)=binaryWater(1,waterCount);waterbit(2)=binaryWater(2,waterCount);waterbit(3)=binaryWater(3,waterCount);
    qblocknew=embedWaterTestQiu(qblock,T,waterbit);
        %--Ƕ��ˮӡ�Ŀ����ԭ��
        for i=1:blocksize
            for j=1:blocksize
                blocknew(i,j,1)=getx(qblocknew(i,j));
                blocknew(i,j,2)=gety(qblocknew(i,j));
                blocknew(i,j,3)=getz(qblocknew(i,j));
            end
        end  
        %----
% po=[6,7;10,11;14,15];
% for i=1:3 
%         if waterbit(i)=='1'
%             blocknew(2,1,i)=ceil(blocknew(2,1,1));
%             blocknew(3,1,i)=floor(blocknew(3,1,1));
%         else
%             blocknew(2,1,i)=floor(blocknew(2,1,1));
%             blocknew(3,1,i)=ceil(blocknew(3,1,1));
%         end 
% end
    for i=1:3
        watermarked((ii-1)*blocksize+1:ii*blocksize,(jj-1)*blocksize+1:jj*blocksize,i)=blocknew(:,:,i);
    end
end

embedtime=toc;
disp(['Ƕ���������ʱ�䣺', num2str(embedtime), ' ��']);
imwrite(uint8(watermarked),'watermarked.bmp');
%--------------------------------------------------

%ˮӡ��ȡ------------------------------------------
tic
watermarked=double(imread('watermarked.bmp'));%k=1;
for waterCount=1:waterlen
    %�ҵ���λ��
    pos=position(waterCount); 
    ii=floor((pos-1)/blocknum)+1;jj=mod(pos-1,blocknum)+1;
    for i=1:3
        block(:,:,i)=watermarked((ii-1)*blocksize+1:ii*blocksize,(jj-1)*blocksize+1:jj*blocksize,i);
    end
    for i=1:blocksize
        for j=1:blocksize
            qblock(i,j)=quaternion(block(i,j,1),block(i,j,2),block(i,j,3));
        end
    end
    waterbit=extractWaterQiu(qblock);
    bwatered(1,waterCount)=waterbit(1);bwatered(2,waterCount)=waterbit(2);bwatered(3,waterCount)=waterbit(3);
    
end
extractwatermark=decry2DLASM(bwatered,sk1,sk2);
extractime=toc;
 disp(['��ȡ��������ʱ�䣺', num2str(extractime), ' ��']);