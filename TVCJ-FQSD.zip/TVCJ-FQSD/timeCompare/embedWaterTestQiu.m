function blocknew=embedWaterTest(qblock,T,waterbit)

[q,r]=qqr(qblock);

r=r*q; 
%xs
r11x=getx(r(1,1));
lmt=fix((r11x/T))*T;
    if waterbit(1)=='1'
        r11x=lmt+0.75*T;
    else
        r11x=lmt+0.25*T;
    end
%y
r11y=gety(r(1,1));
lmt=fix((r11y/T))*T;
    if waterbit(1)=='1'
        r11y=lmt+0.75*T;
    else
        r11y=lmt+0.25*T;
    end
%z
r11z=getz(r(1,1));
lmt=fix((r11z/T))*T;
    if waterbit(1)=='1'
        r11z=lmt+0.75*T;
    else
        r11z=lmt+0.25*T;
    end
r(1,1)=quaternion(scalar(r(1,1)),r11x,r11y,r11z);



blocknew=q*r*pinv(q);  