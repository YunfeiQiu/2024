function waterbit=extractWater(qblock)
load('T.mat');
[q,r]=qqr(qblock);
r=r*q; 

if mod(gety(r(1,1)),T)<0.5*T
    waterbit(2)='0';
else
    waterbit(2)='1';
end

if mod(getz(r(1,1)),T)<0.5*T
    waterbit(3)='0';
else
    waterbit(3)='1';
end

