function waterbit=extractWater(qblock)

[Q,~]=qqr(qblock);

if  abs(getx(Q(2,1))) >= abs(getx(Q(3,1)))
    waterbit(1)='1';
else
    waterbit(1)='0';
end

if  abs(gety(Q(2,1))) >= abs(gety(Q(3,1)))
    waterbit(2)='1';
else
    waterbit(2)='0';
end

if  abs(getz(Q(2,1))) >= abs(getz(Q(3,1)))
    waterbit(3)='1';
else
    waterbit(3)='0';
end

